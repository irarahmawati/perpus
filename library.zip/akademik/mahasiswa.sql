-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2018 at 05:07 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `akademik`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `judul_buku` varchar(50) NOT NULL,
  `isi` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `judul_buku`, `isi`) VALUES
(30, 'Dilan', 'Sinopsis Novel Dilan- Cinta, walaupun sudah berlalu sekian lama, tetap saja, saat dikenang begitu manis.\r\n\r\nMilea, dia kembali ke tahun 1990 untuk menceritakan seorang laki-laki yang pernah menjadi seseorang yang sangat dicintainya, Dilan.\r\n\r\nLaki-laki yang mendekatinya (milea) bukan dengan seikat bunga atau kata-kata manis untuk menarik perhatiannya. Namun, melalui ramalan seperti tergambarkan pada penggalan cerita berikut :\r\n\r\nâ€œAku ramal, nanti kita bertemu di kantin.â€ â€“ Dilan -hlm. 20\r\n\r\nTapi, sayang sekali ramalannya salah. Hari itu, Miela tidak ke kantin karena ia harus membicarakan urusan kelas dengan kawan-kawannya. Sebuah cara sederhana namun bikin senyum dipilih Dilan untuk kembali menarik perhatian dari Milea. Dian mengirim Piyan untuk menyampaikan suratnya yang isinya :\r\n\r\nâ€œMilea, ramalanku, kita akan bertemu di kantin. Ternyata salah. Maaf, tapi ingin meramal lagi : besok kita akan bertemu.â€  â€“ Dilan â€“ halaman. 22\r\n\r\nTunggu, besok yang dimaksud oleh dilan itu adalah hari minggu. Ngga mungkin, kan mereka bertemu? Namun, ternyata ramalannya kali ini benar. Dilan datang ke rumah Miela untuk menyampaikan surat undangannya yang isinya :\r\n\r\nâ€œBismillahirrahmanirrahim. Dengan nama Allah Yang Maha Pengasih lagiPenyayang. Dengan ini, dengan penuh perasaan, mengundang Milea Adnan untuk sekolah pada : Hari Senin, Selasa, Rabu, Kamis, Jumat, dan Sabtu.â€ â€“ Dilan â€“ hlm. 27\r\n\r\nHal-hal yang sederhana ini nyatanya dapat membuat Milea tersenyum, dan perlahan mulai menaruh perhatiannya kepada Dilan. Sampai-sampai, sebentar dia lupa, ada Beni yaitu pacarnya yang berada di Jakarta.\r\n\r\nMilea tak mau kehilangan Dilan. Baginya, Dilan seperti sesuatu yang selalu dapat membuat hari-harinya penuh warna. Tapi, dia tampak sangat jahat pada Dilan, karena dia mau untuk menerima perhatian dari Dilan, padahal dia sudah ada yang memiliki.\r\n\r\nSampai pada waktu milea memutuskan hubungannya dengan beni, pacarnya di jakarta. Ia cowok yang sangat emosian dan manja. Karena suatu hal yang ga perlu dijelaskan. Semenjak itu hubugan Dilan dan Milea semakin erat saja.'),
(32, 'Hujan', 'Cerita dimulai saat Lail ingin berangkat sekolah,\r\ndi tahun 2042, saat breaking news tentang krisis\r\nair begitu mengkhawatirkan penduduk bumi. Lail,\r\nyang kala itu masih kecil, belum mengerti.\r\nSampai akhirnya bencana itu terjadi. Bencana yang\r\nmembuatnya jadi anak yatim piatu.\r\n\r\nDan saat itulah ia bertemu Esok, pemuda baik yang\r\nmenjadi sosok kakak untuk Lail. Lail dan Esok adalah\r\nanak-anak berbakat yang memiliki keterampilan.\r\n\r\nTere Liye mengisahkan kisah ini dengan begitu\r\nmenyenangkan. Saya diajak berimajinasi tentang bumi di\r\nmasa depan. Saya diajak bertualang bersama Lail dan\r\nMaryam, sahabat Lail dengan rambut kribo, dalam\r\nmelewati tes. Saya ikut khawatir dengan hujan yang\r\nberbahaya. Saya ikut cemas memikirkan nasib Lail dan\r\nEsok. Saya ikut waswas dengan akhir cerita pasangan\r\nini.'),
(33, 'Perahu Kertas', 'dimulai dengan kisah seorang anak muda bernama Keenan.\r\nIa seorang remaja yang baru saja menyelesaikan sekolah\r\nmenengah atas-nya di Belanda, tepatnya di Amsterdam. Keenan\r\nmenetap di Negara tersebut selama hampir 6 tahun lamanya,\r\nbersama sang nenek. Keenan terlahir dengan cita-cita\r\nmenjadi pelukis. Namun, ia dipaksa untuk kembali ke\r\nIndonesia oleh sang Ayah. Keluarganya tidak mendukung\r\nKeenan menjadi seorang pelukis. Ia pada akhirnya memulai\r\nperkuliahan di salah satu Universitas di Bandung. Ia\r\nmengalah dan memutuskan untuk belajar di Fakultas Ekonomi.\r\n\r\nTokoh sentral lainnya adalah wanita bertubuh mungil bernama\r\nKugy. Ia digambarkan dengan kepribadian yang riang dan\r\nceria. Berbeda dengan Keenan yang cenderung dingin dan\r\nkaku. Kugy juga merupakan sosok yang eksentrik pun\r\nnyentrik. Ia akan sangat mudah dikenali jika ada di dalam\r\nkerumunan. Kugy menggilai dongeng dan kisah klasik. Sedari\r\nkecil ia bercita-cita menjadi seorang penulis dongeng. Ia\r\nmemiliki sejumlah koleksi buku dongeng, ingin penjadi\r\nseorang perancang dongen pun juru dongeng. Namun di tengah\r\nimpiannya yang menggebu, kenyataan memaksanya sadar bahwa\r\npenulis dongen bukan profesi yang banyak menghasilkan\r\nmateri. Kugy dipaksa untuk menyimpan mimpinya demi sebuah\r\nrasionalitas pun realisme. Meski demikian, tokoh Kugy ini\r\ntidak patah arang. Ia mencintai dunia tulis-menulis. Hal\r\nini yang membuat ia melanjutkan pendidikannya di Fakultas\r\nSastra di salah satu Universitas di Bandung. Tempat kuliah\r\nyang sama dengan tokoh lainnya, Keenan.\r\n\r\nPertemuan antara kedua tokoh ini tak terlepas dari tokoh\r\nlain yakni Noni dan Eko. Noni tokoh pendukung cerita yang\r\nmerupakan sahabat dekat Kugy. Sementara itu, Eko adalah\r\nsepupu Keenan. Pertemuan pertama Kugy dan Keenan adalah\r\nmomen dimana Eko dan Noni menjemput Keenan yang baru tiba\r\ndi Indonesia.\r\n\r\nSeiring berjalannya waktu, Kugy pun Keenan menjalin\r\npersahabatan bersama Eko dan Noni. Diam-diam, mereka saling\r\nmengagumi. Kugy yang senang bercerita lewat dongeng merasa\r\ntakjub bertemu dengan Keenan, seseorang yang mampu\r\nbercerita lewat gambar. Mereka diam-diam jatuh cinta dalam\r\ndiam. Namun, kondisi menuntut mereka untuk terus diam dan\r\nmenebak. â€œDiamâ€-nya mereka terhadap perasaan masing-masing\r\nsemakin menjadi dikarenakan Kugy telah memiliki pacar\r\nbernama Ojos atau Joshua. Sementara itu, Keenan yang belum\r\nmemiliki pasangan, hendak dijodohkan dengan tokoh bernama\r\nWanda. Wanda sendiri adalah seorang Kurator. Hal ini yang\r\nmembuat Eko juga Noni bersemangat mendekatkannya dengan\r\nKeenan yang jago melukis.\r\n\r\nPersahabatan Kugy, Keenan, Eko dan Noni berjalan apa\r\nadanya. Namun lambat laun mereka renggang. Kugy sibuk\r\ndengan muridnya di sekolah darurat. Ia menjadi salah satu\r\nguru relawan. Ia mengajar dengan cara mendongeng. Anak-anak\r\nyang semula usil pada Kugy, berbalik suka berkat dongeng\r\npetualangan berjudul â€œJenderal Pilik dan Pasukan Alitâ€.\r\nDongeng tersebut dituliskan Kugy dalam sebuah buku. Di\r\nwaktu mendatang, buku dongeng tersebut ia berikan pada\r\nKeenan.\r\n\r\nLain lagi dengan Keenan, ia juga sibuk dengan kehidupannya\r\ntermasuk kedekatannya dengan Wanda. Pada mulanya, hubungan\r\nmereka baik-baik saja. Namun, beberapa waktu hubungan\r\ntersebut menjadi pelik dan menghentak Keenan. Ia menyadari\r\nbahwa apa yang ia berusaha bangun, hancur dalam hitungan\r\nwaktu semalam. Ia sedih, remuk dan kecewa. Keenan pun\r\nmemutuskan untuk meninggalkan Kota Bandung menuju Kota\r\nBali. Di Pulau Dewata tersebut, Keenan tinggal dengan Pak\r\nWayan. Sahabat ibunya Sebelum pergi, Kugy memberi Keenan\r\nbuku dongen â€œJenderal\r\nPilik dan Pasukan Alitâ€. Keenan membawanya ke Bali. Di\r\ntempat Pak Wayan, perlahan Keenan membangun hidup dan\r\nmimpinya kembali. Ia hidup bersama banyak seniman dan \r\nmenjadikan naluri seninya dalam melukis semakin terasah. Di\r\nBali, Keenan mengagumi Luhde Laksmi, keponakan Pak Wayan.\r\nPada akhirnya, Setelah beberapa waktu, Keenan menjadi salah\r\nsatu pelukis yang karyanya diburu. Ia menciptakan serial\r\nlukisan yang digemari kolektor. Kisah tersebut adalah\r\ndongeng yang sebelumnya Kugy berikan.\r\n\r\nSementara itu, selepas kuliah Kugy kembali ke Jakarta dan\r\nmenjadi seorang Copywriter. Ia kemudian menjalin hubungan\r\ndengan atasannya yang juga merupakan karib kakaknya. Ia dan\r\nRemi menjalin hubungan meski diam-diam Kugy masih sering\r\nmengenang Keenan. Sampai suatu waktu, Kugy kembali bertemu\r\ndengan Keenan yang terpaksa meninggalkan Bali karena\r\nayahnya terkena serangan stroke. Keenan harus melanjutkan\r\nperusahaan ayahnya. Pertemuan Kugy dan Keenan di kondisi\r\nyang berbeda ini membuat mereka tak bisa lagi menahan\r\nperasaan masing-masing. Konflik dimulai dari sini.\r\n\r\nSecara umum, Dee mengemas cerita cinta ini dengan sederhana\r\nnamun sarat makna. Kisah ini tentang pencarian cinta yang\r\ndibiarkan mengalir hingga kebali bermuara seperti perahu\r\nkertas. Melalui Kugy dan Keenan, Dee menyajikan cerita\r\ncinta yang biasa namun dalam. Pemilihan kata serta alur\r\ntaktis membuat kisah di dalam novel Perahu Kertas ini\r\nmenarik untuk dibaca. Meski temanya teramat ringan, namun\r\nsignatur dee dalam derita ini sama memikatnya dengan buku\r\nbertema berat milik dee lainnya.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
