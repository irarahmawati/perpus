<!DOCTYPE html>

<html>
<head>
<title>Library</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>	
<body id="top">

<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/a.jpg');"> 
  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <div id="logo" class="fl_left">
        <h1><a href="index.html">Library</a></h1>
      </div>
      <nav id="mainav" class="fl_right">
        <ul class="clear">
         	<li><a href="index2.php?page=home">HOME</a></li>
			<li><a href="index2.php?page=tutorial">BOOK</a></li>
			<li><a href="index2.php?page=login">LOGIN</a></li>
        </ul>
      </nav>
    </header>		
    <ul>

		</ul>
	</div>
	<div id="pageintro" class="hoc clear">
    <div class="flexslider basicslider">
      <ul class="slides">
        <li>
          
        </li>
        </li>
      </ul>
    </div>
  </div>
</div>
 
	<div class="badan">
 
 
	<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) {
			case 'home':
				include "jajal.php";
				break;
			case 'tutorial':
				include "halaman2.php";
				break;	
			case 'login':
				include "formlogin.php";
				break;		
			default:
				echo "<center><h3>Maaf. Halaman tidak di temukan !</h3></center>";
				break;
		}
	?>
  	<?php
	}else{
		include "jajal.php";
	}
 
	 ?>
	</div>
</div>
</body>
</html>