<head>
<title>Gallery</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body>
<right>
</span>
</right>
<center>
			<div class="wrap-table100">
				<div class="table100 ver1 m-b-110">
					<div class="table100-head">
 <div class="wrapper row3">
  <main class="hoc container clear"> 
    <div class="content"> 
      <div id="gallery">
        <figure>
          <header class="heading">Pilihan Buku</header>
          <ul class="nospace clear">
            <li class="one_quarter first"><a href="#"><img src="photo/1.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/2.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/3.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/4.jpg" alt=""></a></li>
            <li class="one_quarter first"><a href="#"><img src="photo/5.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/6.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/13.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/8.jpg" alt=""></a></li>
            <li class="one_quarter first"><a href="#"><img src="photo/9.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/10.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/11.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/12.jpg" alt=""></a></li>
            <li class="one_quarter first"><a href="#"><img src="photo/14.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/15.png" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/16.jpg" alt=""></a></li>
            <li class="one_quarter"><a href="#"><img src="photo/17.jpg" alt=""></a></li>
          </ul>

        </figure>
        </li>
        <li>
     