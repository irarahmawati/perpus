<?php

include 'koneksi.php';
 
$judul_buku = $_POST['judul_buku'];
$isi = $_POST['isi'];
 
mysqli_query($koneksi,"insert into mahasiswa values('','$judul_buku','$isi')");

header("location:index2.php");

 
?>