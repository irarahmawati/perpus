<!DOCTYPE html>
<html>
<head>
	<center><title>edit</title></center>
	<link rel="stylesheet" href="login.css" type="text/css" href="">
</head>
<body>
 <center>
	<h3>Edit Buku</h3>
</center>
	<div class="login-card">
 
	<?php
	include 'koneksi.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from mahasiswa where id='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="update.php">
			<table>
				<tr>			
					<td>judul buku</td>
					<td>
						<input type="hidden" name="id" value="<?php echo $d['id']; ?>">
						<input type="text" name="judul_buku" value="<?php echo $d['judul_buku']; ?>">
					</td>
				</tr>
				<tr>
					<td>isi</td>
					<td><textarea type="text" name="isi" value="<?php echo $d['isi']; ?>"></textarea></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
	<center><button><a href="index2.php">KEMBALI</a></button></center>
		<?php 
	}
	?>
 
</body>
</html>