<head>
<title>buku</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<div class="wrapper row3">
  <main class="hoc container clear"> 
   <center>
      <div class="wrap-table100">
        <div class="table100 ver1 m-b-110">
          <div class="table100-head">
            
            <table>
              <thead>
                <center>
                <h2> Data Peminjam Buku </h2>
      <tr class="row100 head">
                  <th class="cell100 column0">No</th>
                  <th class="cell100 column1">Judul Buku</th>
                  <th class="cell100 column3">isi</th>
                </tr>
              </thead>
            </table>
          </div>
    </tr>

    <div class="table100-body js-pscroll">
  <table>
              <tbody>
              <tr class="row100 body">
    <?php 
    include 'koneksi.php';
    $no = 1;
    $data = mysqli_query($koneksi,"select * from mahasiswa");
    while($d = mysqli_fetch_array($data)){
      ?>
      <tr>
        <td class="cell100 column0"><?php echo $no++; ?></td>
        <td class="cell100 column1"><?php echo $d['judul_buku']; ?></td>
        <td class="cell100 column2"><?php echo $d['isi']; ?></td>
      </tr>
      <?php 
    }
    ?>
                </tr></tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>